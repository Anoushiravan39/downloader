	
	<!DOCTYPE html>
<html>
	<head>
		
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta charset="utf-8" />
		    
                    <link rel="stylesheet" type="text/css" media="screen" href="https://rule34.xxx//css/desktop.css?46" title="default" />
            		<script nomodule src="/script/core-js.js" type="text/javascript"></script>
<script src="https://rule34.xxx/script/application.js?33" type="text/javascript"></script>
<script src="/script/awesomplete.min.js?v33" type="text/javascript"></script>


<script>
				window.captchaSiteKey = "0x4AAAAAAAES4wLGEtgDhNX6";
                window.captchaCSSClass = "cf-turnstile";
                window.captchaProvider = "turnstile";
				window.captchaInstance = "tst2";
				window.captchaInstanceFormKey = "captchaKey";
				window.captchaResponseFormKey = "cf-turnstile-response";
				window.captchaRenderIdFn = (id) => '#' + id;
				window.getCaptcha = function() {
					if (window["turnstile"]) {
						return turnstile; 
					} else {
						return undefined;
					}
                }

				window.captchaScriptLoaded = false;
				window.loadCaptchaScript = function() {
					if (window.captchaScriptLoaded) return; 
					window.captchaScriptLoaded = true;
					const script = document.createElement('script');
					script.src = "https://challenges.cloudflare.com/turnstile/v0/api.js?onload=loadedCaptchaScript";
					document.body.appendChild(script);
					
					return new Promise((res, rej) => {
						window.loadedCaptchaScript = () => {
							console.log("loaded");
							res();
						}
						script.onerror = function () {
							rej();
						}
					});
				}
</script>

		<link rel="shortcut icon" href="/favicon.ico" />
		<meta name="theme-color" content="#ffffff">
		<title>Rule 34 - 3girls asahina aoi big breasts breasts busty danganronpa danganronpa 3 dark-skinned female dark skin female female only hourglass figure huge breasts hypnosis kirigiri kyouko large breasts light-skinned female light skin long hair mind control multiple females multiple girls naked nipples nude pale-skinned female pale skin ponytail pussy shinzu031 voluptuous voluptuous female yukizome chisa | 8690920</title>
		<meta name="keywords" content="Rule 34, imageboard, 3girls, asahina aoi, big breasts, breasts, busty, danganronpa, danganronpa 3, dark-skinned female, dark skin, female, female only, hourglass figure, huge breasts, hypnosis, kirigiri kyouko, large breasts, light-skinned female, light skin, long hair, mind control, multiple females, multiple girls, naked, nipples, nude, pale-skinned female, pale skin, ponytail, pussy, shinzu031, voluptuous, voluptuous female, yukizome chisa" />
		<meta name="description" content="Rule 34 - If it exists, there is porn of it. We have pokemon, my little pony, Other hentai, whatever you want.">


		<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
		<link rel="mask-icon" href="/safari-pinned-tab.svg" color="#5bbad5">
		 
			<script type="text/javascript" src="/ads/adhelper.js"></script> 
		 
			<meta name="rating" content="mature" /> 
		
		<link rel="search" type="application/opensearchdescription+xml" title="Rule 34: Coded by Geltas" href="openSearchDesc.xml" />

		<link href="https://rule34.xxx/index.php?page=atom&tags=3girls asahina aoi big breasts breasts busty danganronpa danganronpa 3 dark-skinned female dark skin female female only hourglass figure huge breasts hypnosis kirigiri kyouko large breasts light-skinned female light skin long hair mind control multiple females multiple girls naked nipples nude pale-skinned female pale skin ponytail pussy shinzu031 voluptuous voluptuous female yukizome chisa" rel="alternate" title="ATOM" type="application/atom+xml"/>
</head>
<body id="body">

		
	<script>if(typeof testvar !=='undefined') fetch ("/?page=notify1&a=0"); </script>
<script src="/script/fluidplayer/fluidplayer.min.js?33"></script>

        <div id="header">

			<input type="radio" class="tradio" id="rmainmenu" name="navtrigs" />
			<input type="radio" class="tradio" id="rnomenu1" name="navtrigs" checked />
			<input type="radio" class="tradio" id="rsubmenu" name="navtrigs" /> 
			<input type="radio" class="tradio" id="rnomenu2" name="navtrigs" />
			<label for="rmainmenu" class="tlabel tfirst" id="rlmainmenu"></label>
			<label for="rnomenu1" class="tlabel tnomenu tfirst" id="rlnomenu1"></label>
			<label for="rsubmenu" class="tlabel tsecond" id="rlsubmenu"></label>
			<label for="rnomenu2" class="tlabel tnomenu tsecond" id="rlnomenu2"></label>

			<h2 id="site-title">
									<a href="https://rule34.xxx/">Rule 34</a>
				
							</h2>
			<ul class="flat-list" id="navbar">
			<li><a href="https://rule34.xxx/index.php?page=account&s=home">My Account</a></li>
			<li class="current-page"><a href="https://rule34.xxx/index.php?page=post&s=list&tags=all">Posts</a></li>
			<li><a href="https://rule34.xxx/index.php?page=comment&s=list">Comments</a></li>
			<li><a href="https://rule34.xxx/index.php?page=wiki&s=list">Wiki</a></li>
			<li><a href="https://rule34.xxx/index.php?page=alias&s=list">Aliases</a></li>
			<li><a href="https://rule34.xxx/index.php?page=artist&s=list">Artists</a></li>
			<li><a href="https://rule34.xxx/index.php?page=tags&s=list">Tags</a></li>
			<li><a href="https://rule34.xxx/index.php?page=pool&s=list">Pools</a></li>
			<li><a href="https://rule34.xxx/index.php?page=forum&s=list">Forum</a></li>
													<li><a href="https://rule34.xxx/index.php?page=icame">iCame Top 100</a></li>
									<li><a href="https://rule34.xxx/index.php?page=help">Help</a></li>
			<li><a href="https://discord.gg/rule34xxx" target="_blank" rel="noopener noreferrer">Discord</a></li>
			<li><a href="https://x.com/slayerduckie" target="_blank" rel="noopener noreferrer">X</a></li>
			    <li><a style="font-weight: bolder; color: #e26c5e;" rel="sponsored" href="https://s.happyleafmotion.com/v1/d.php?z=2694" target="_blank">💦 AI CUMSLUTS</a></li>						<li><a style="font-weight: bolder" href="/link.php">Other Sites</a></li>

			<script>
				function desktop_layout() {
					document.cookie = "experiment-mobile-layout=false; expires=Fri, 31 Dec 9999 23:59:59 GMT";
					location.reload();
				}

				function mobile_layout() {
					document.cookie = "experiment-mobile-layout=; expires=Thu, 01 Jan 1970 00:00:00 GMT";
					location.reload();
				}
			</script>

												</ul>
<ul class="flat-list" id="subnavbar" style="margin-bottom: 1px;">
    <li><a href="index.php?page=post&amp;s=list&tags=video">Video</a></li>
    <li><a href="index.php?page=post&amp;s=add">Upload</a></li>
    <li><a href="index.php?page=post&amp;s=addVideo">Upload Video</a></li>

                                                                                                                                                                                                                <li><a href="index.php?page=post&amp;s=random">Random</a></li>
    <li><a href="/cdn-cgi/l/email-protection#75060114131335171a1a07005b1a0712">Contact Us</a></li>
    <li><a href="/cdn-cgi/l/email-protection#fa9e97999bba989595888fd495889d">DMCA</a></li>
    <li><a href="index.php?page=about">About</a></li>
    <li><a href="index.php?page=help&amp;topic=post">Help</a></li>
    <li><a href="/index.php?page=tos">TOS</a></li>
        </ul> 
		</div>
		<div id="long-notice"></div>
		<div id="notice" class="notice" style="display: none;"></div>
		<div class="has-mail" id="has-mail-notice"  style="display: none;">
		<a href="/index.php?page=gmail">You have mail</a></div>
		 

    <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script async type="application/javascript" src="https://a.magsrv.com/ad-provider.js"></script>
    
<meta property="og:title" content="Rule 34" />
<meta property="og:site_name" content="Rule 34" />
<meta property="og:image" itemprop="image" content="https://wimg.rule34.xxx//images/7617/c6468106d221b45d006ddc759185f08d.png?8690920" />	

<div id="content">
	<div id="post-view">
		<div class="sidebar">
			<div class="tag-search">
    <h5>Search</h5>
    <form action="index.php?page=search" method="post" >
            <input name="tags" type="text" value=""/> 
            <br />
            <input name="commit" type="submit" value="Search" />
    </form>
    <small>(Supports wildcard *)</small>
</div>			
			<span data-nosnippet>
				<ins class="eas6a97888e38" data-zoneid="5232472"></ins>
			</span>

			<ul id="tag-sidebar">
                    <li><h6>Copyright</h6></li>
                            <li class="tag-type-copyright tag">
					<a href="index.php?page=wiki&s=list&search=danganronpa">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=danganronpa">danganronpa</a>
                    <span class="tag-count">43369</span>
                </li>
                                <li class="tag-type-copyright tag">
					<a href="index.php?page=wiki&s=list&search=danganronpa_3">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=danganronpa_3">danganronpa 3</a>
                    <span class="tag-count">2312</span>
                </li>
                                <li><h6>Character</h6></li>
                            <li class="tag-type-character tag">
					<a href="index.php?page=wiki&s=list&search=asahina_aoi">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=asahina_aoi">asahina aoi</a>
                    <span class="tag-count">1885</span>
                </li>
                                <li class="tag-type-character tag">
					<a href="index.php?page=wiki&s=list&search=kirigiri_kyouko">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=kirigiri_kyouko">kirigiri kyouko</a>
                    <span class="tag-count">3284</span>
                </li>
                                <li class="tag-type-character tag">
					<a href="index.php?page=wiki&s=list&search=yukizome_chisa">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=yukizome_chisa">yukizome chisa</a>
                    <span class="tag-count">676</span>
                </li>
                                <li><h6>Artist</h6></li>
                            <li class="tag-type-artist tag">
					<a href="index.php?page=wiki&s=list&search=shinzu031">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=shinzu031">shinzu031</a>
                    <span class="tag-count">220</span>
                </li>
                                <li><h6>General</h6></li>
                            <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=3girls">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=3girls">3girls</a>
                    <span class="tag-count">131180</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=big_breasts">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=big_breasts">big breasts</a>
                    <span class="tag-count">3461262</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=breasts">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=breasts">breasts</a>
                    <span class="tag-count">7940912</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=busty">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=busty">busty</a>
                    <span class="tag-count">414307</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=dark_skin">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=dark_skin">dark skin</a>
                    <span class="tag-count">986121</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=dark-skinned_female">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=dark-skinned_female">dark-skinned female</a>
                    <span class="tag-count">429464</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=female">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=female">female</a>
                    <span class="tag-count">10008799</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=female_only">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=female_only">female only</a>
                    <span class="tag-count">2182183</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=hourglass_figure">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=hourglass_figure">hourglass figure</a>
                    <span class="tag-count">339634</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=huge_breasts">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=huge_breasts">huge breasts</a>
                    <span class="tag-count">2114289</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=hypnosis">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=hypnosis">hypnosis</a>
                    <span class="tag-count">67698</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=large_breasts">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=large_breasts">large breasts</a>
                    <span class="tag-count">2464202</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=light_skin">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=light_skin">light skin</a>
                    <span class="tag-count">1371402</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=light-skinned_female">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=light-skinned_female">light-skinned female</a>
                    <span class="tag-count">1188283</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=long_hair">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=long_hair">long hair</a>
                    <span class="tag-count">2655462</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=mind_control">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=mind_control">mind control</a>
                    <span class="tag-count">80412</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=multiple_females">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=multiple_females">multiple females</a>
                    <span class="tag-count">218693</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=multiple_girls">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=multiple_girls">multiple girls</a>
                    <span class="tag-count">538313</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=naked">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=naked">naked</a>
                    <span class="tag-count">767980</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=nipples">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=nipples">nipples</a>
                    <span class="tag-count">4340137</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=nude">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=nude">nude</a>
                    <span class="tag-count">3689317</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=pale_skin">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=pale_skin">pale skin</a>
                    <span class="tag-count">383390</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=pale-skinned_female">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=pale-skinned_female">pale-skinned female</a>
                    <span class="tag-count">214164</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=ponytail">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=ponytail">ponytail</a>
                    <span class="tag-count">513089</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=pussy">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=pussy">pussy</a>
                    <span class="tag-count">3882963</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=voluptuous">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=voluptuous">voluptuous</a>
                    <span class="tag-count">760976</span>
                </li>
                                <li class="tag-type-general tag">
					<a href="index.php?page=wiki&s=list&search=voluptuous_female">?</a>
                    <a href="index.php?page=post&amp;s=list&amp;tags=voluptuous_female">voluptuous female</a>
                    <span class="tag-count">316949</span>
                </li>
                </ul>
			<div>
    <script type="text/javascript">
        function iCame(c){	var a; try{a=new XMLHttpRequest()}catch(b){try{a=new ActiveXObject("Msxml2.XMLHTTP")}catch(b){try{a=new ActiveXObject("Microsoft.XMLHTTP")}catch(b){alert("Your browser is to old or does not support Ajax.")}}}a.onreadystatechange=function(){if(a.readyState==4) {notice(a.responseText);}};a.open("GET","/public/icame.php?postid=" + c,true);a.send(null)}
    </script>

    <h5>Cum on this</h5>
        <ul>
            You can cum every 24 hours.<br \>
            Explanation <a href="/index.php?page=forum&amp;s=view&amp;id=192#1153">here</a> and <a href="/index.php?page=icame">top list here.</a>
            <li>
                <a href="#" onclick="iCame('8690920'); return false;"><img src="https://rule34.xxx/static/icame.png" alt="I came!" /></a>
            </li>
        </ul>
</div>
			
			<div id="stats">
    <h5>Statistics</h5>
    <ul>
        <li>Id: 8690920</li>
        <li>
            Posted: 2023-09-24 12:34:56<br /> 
            by 
            <a href="index.php?page=account&amp;s=profile&amp;uname=Bylethlover">
                Bylethlover            </a>
        </li>
        <li>Size: 1550x1094</li>
        <li>Source: <a href="https://hypnohub.net/index.php?page=post&amp;s=view&amp;id=104048" rel="nofollow">hypnohub.net/index.php?page=post&amp;s=view&amp;id=104048</a></li>        <li>Rating: Explicit</li>
        <li>
            Score: <span id="psc8690920">67</span> 

                                    (vote <a href="#" onclick="Javascript:post_vote('8690920', 'up'); return false;">up</a>)
                                </li>
    </ul>
</div>			
			<div class="link-list">
    <h5>Options</h5>
    <ul>
        <li>
            <a href="#" onclick="toggleEditForm(); return false;" >Edit</a>
        </li>
                <li>
            <a href="#" onclick="Note.sample=false; Post.sample(); $('resized_notice').show(); return false;">Resize image</a>
        </li>
        <li>
            <a href="https://wimg.rule34.xxx//images/7617/c6468106d221b45d006ddc759185f08d.png?8690920" 
                onclick="Post.highres(); $('resized_notice').hide(); Note.sample=false; return false;" style="font-weight: bold;">
                Original image
            </a>
        </li>
        
        
        
                    <li>
                <div id="pfd">
                                            <a href="#" onclick="pflag('8690920'); return false;">Report to moderation</a>
                                    </div>
            </li>
        
        <li>
            <a href="#" onclick="Note.create(284392); return false;">Add Note</a>
        </li>
        
        <li>
            <a href="#" onclick="post_vote('8690920', 'up'); addFav('8690920'); return false;">Add to favorites</a>
        </li>

            </ul>
</div>
			<div class="link-list">
    <h5>History</h5>
    <ul>
        <li><a href="index.php?page=history&amp;type=tag_history&amp;id=8690920">Tags</a></li>
        <li><a href="index.php?page=history&amp;type=page_notes&amp;id=8690920">Notes</a></li>
    </ul>
</div>
			<div class="link-list">
    <h5>Related Posts</h5>
    <ul>
                    <li><a href="index.php?page=post&amp;s=view&amp;id="5099299">Parent</a></li>
        
        <li><a href="http://saucenao.com/search.php?db=999&url=https://wimg.rule34.xxx/thumbnails//7617/thumbnail_c6468106d221b45d006ddc759185f08d.jpg" rel="nofollow">Saucenao</a></li>
        <li><a href="http://iqdb.org/?url=https://wimg.rule34.xxx/thumbnails//7617/thumbnail_c6468106d221b45d006ddc759185f08d.jpg" rel="nofollow">Similar</a></li>
        <li><a href="http://waifu2x.booru.pics/Home/fromlink?denoise=1&scale=2&url=https://wimg.rule34.xxx//images/7617/c6468106d221b45d006ddc759185f08d.png?8690920" rel="nofollow">Waifu2x</a></li>
        
        <br />
    </ul>
</div>
												<img src="/images/r34chibi.png" />
									</div>

		<div class="content" id="right-col">

			<div id="fit-to-screen">

				<div id="status-notices">
						<div class="status-notice">
			This post belongs to a 
				<a href="index.php?page=post&amp;s=view&amp;id=5099299"><b>parent post</b></a>. 
			Child posts are often subsequent pages of a doujinshi, or minor variations of the parent post.
		</div>
		<br /><br />
				<div class="status-notice" style="display: none;" id="resized_notice">
			This image has been resized. Click <a href="#" onclick="Post.highres(); $('resized_notice').hide(); Note.sample=false; return false;">here</a> to view the original image.
			<a href="#" onclick="Cookie.create('resize-original',1); Cookie.create('resize-notification',1); Post.highres(); $('resized_notice').hide(); return false;">Always view original</a>.
			<a href="#" onclick="Cookie.create('resize-notification',1); $('resized_notice').hide(); return false;">Don't show this message</a>.
		<script type="text/javascript">
			Note.sample = true;
			var resize_notification_cookie = Cookie.get('resize-notification');
			if(resize_notification_cookie != 1)
			{
				$('resized_notice').show();
			}
		</script>
		</div>
	
							
	</div>
				<div class="flexi">
					<div id="">
						<div id="pv_leaderboard" data-nosnippet>
							
													</div>

						
<script>
    // megacache time

    var id = "8690920";
    var searchTags = "all";
    var aiFiltered = "0";
    var storageKey = searchTags + "_" + "aif" + aiFiltered;

    const baseUrl = "https:\/\/rule34.xxx\/public\/post_helpers2.php" + "?action=fetch_id_cache";

    function hasPrevNext() {
        let time = parseInt(sessionStorage.getItem("lastRefresh"));
        if ((Number.isInteger(time) && Date.now() - time > 1000 * 60 * 10) || isNaN(time)) {
            sessionStorage.clear();
        };

        let storageItem = sessionStorage.getItem(storageKey);
        let storage = [];
        if (storageItem !== null) {
            storage = JSON.parse(storageItem);
            var idx = storage.findIndex((v) => v == id);
            if (idx == -1) { // index not found, rebuild storage#
                return false;
            } else if (idx == 0) { // need more to the left
                return false;
            } else if (idx == storage.length - 1) { // need more to the right
                return false;
            } 
            return true;
        }
    }

    async function getPrevNext() {

        let time = parseInt(sessionStorage.getItem("lastRefresh"));
        if ((Number.isInteger(time) && Date.now() - time > 1000 * 60 * 10) || isNaN(time)) {
            sessionStorage.clear();
        };

        let storageItem = sessionStorage.getItem(storageKey);
        let storage = [];
        if (storageItem == null) {
            const data = await fetch(baseUrl + "&tags=" + searchTags + "&id=" + id)
                .then((response) => response.json())
                .catch((error) => {
                    notice("Error...");
                });
            storageItem = JSON.stringify(data);
            storage = data;
            sessionStorage.setItem(storageKey, storageItem);
            sessionStorage.setItem("lastRefresh", Date.now());
        } else {
            storage = JSON.parse(storageItem);
            var idx = storage.findIndex((v) => v == id);


            if (idx == -1) { // index not found, rebuild storage#
                const data = await fetch(baseUrl + "&tags=" + searchTags + "&id=" + id)
                    .then((response) => response.json())
                    .catch((error) => {
                        notice("Error...");
                    });
                storage = data;
                storageItem = JSON.stringify(storage);
                sessionStorage.setItem(storageKey, storageItem);
                sessionStorage.setItem("lastRefresh", Date.now());
            } else if (idx == 0) { // need more shit to the left (higher)
                const data = await fetch(baseUrl + "&direction=next&tags=" + searchTags + "&id=" + id)
                    .then((response) => response.json())
                    .catch((error) => {
                        notice("Error...");
                    });
                storage = data.concat(storage);
                storageItem = JSON.stringify(storage);
                sessionStorage.setItem(storageKey, storageItem);
                sessionStorage.setItem("lastRefresh", Date.now());
            } else if (idx == storage.length - 1) { // need more shit to the right (lower)
                const data = await fetch(baseUrl + "&direction=prev&tags=" + searchTags + "&id=" + id)
                    .then((response) => response.json())
                    .catch((error) => {
                        notice("Error...");
                    });
                storage = storage.concat(data);
                storageItem = JSON.stringify(storage);
                sessionStorage.setItem(storageKey, storageItem);
                sessionStorage.setItem("lastRefresh", Date.now());
            }
        }

        var idx = storage.findIndex((v) => v == id);
        var idxLeft = -1;
        var idxRight = -1;
        if (idx < -1) {
            //wtf
        }
        if (idx > 0) {
            idxLeft = idx - 1;
        }
        if (idx < storage.length - 1) {
            idxRight = idx + 1
        }

        return [storage[idxLeft], storage[idxRight]];
    }
</script>


    <template id="prevLinkTmpl">
        <div style="font-size: 15px;">
            <a href="#" id="prev_search_link">
                &lt; previous
            </a>
        </div>
    </template>

    <template id="nextLinkTmpl">
        <div style="font-size: 15px;">
            <a href="#" id="next_search_link">
                next &gt;
            </a>
        </div>
    </template>


    <div id="navlinksContainer" class="status-notice flexi" style="justify-content: space-evenly;">
        <div style="text-align: center">
                    </div>
    </div>

    <script>
        document.onkeydown = function(ev) {
            var dontdo = [
                "INPUT",
                "TEXTAREA", 
                "VIDEO",
                "BUTTON",
            ];
            if (dontdo.includes(ev.target.nodeName)) { return true; }            
            if (!ev.altKey && !ev.ctrlKey && !ev.metaKey && !ev.metaKey) {
                switch (ev.key) {
                    case "ArrowLeft":
                    //case "a":
                        if ($("prev_search_link"))
                            $("prev_search_link").click()
                            return false;
                        break;
                    case "ArrowRight":
                    //case "d":
                        if ($("next_search_link"))
                            $("next_search_link").click()
                            return false;
                        break;
                }
            }
            
        };
    </script>


<script>
    document.idsFetched = false;
    document.ids = null;
    (async function() {
        var container = document.querySelector("#navlinksContainer");
        var baseLink = "\/index.php?page=post&s=view&id=IDPLACEHOLDER"
        // if (idPrev != undefined) {
        //     const prevTmpl = document.querySelector("#prevLinkTmpl");
        //     const prevNode = prevTmpl.content.cloneNode(true);
        //     prevNode.querySelector("a").href = prevNode.querySelector("a").href.replace("IDPLACEHOLDER", idPrev);
        //     container.prepend(prevNode);
        // }

        // if (idNext != undefined) {
        //     const nextTmpl = document.querySelector("#nextLinkTmpl");
        //     const nextNode = nextTmpl.content.cloneNode(true);
        //     nextNode.querySelector("a").href = nextNode.querySelector("a").href.replace("IDPLACEHOLDER", idNext);
        //     container.append(nextNode);
        // }

        const prevTmpl = document.querySelector("#prevLinkTmpl");
        const nextTmpl = document.querySelector("#nextLinkTmpl");
        const prevNode = prevTmpl.content.cloneNode(true);
        const nextNode = nextTmpl.content.cloneNode(true);
        const fetcherFunc = async function() {
            if (document.idsFetched == false) {
                document.idsFetched = true;
                document.ids = await getPrevNext();
                var idPrev = document.ids[0];
                var idNext = document.ids[1];
                if (idPrev != undefined) {
                    document.querySelector("#prev_search_link").href = baseLink.replace("IDPLACEHOLDER", idPrev);
                } else {
                    document.querySelector("#prev_search_link").style.display = "none";
                }
                if (idNext != undefined) {
                    document.querySelector("#next_search_link").href = baseLink.replace("IDPLACEHOLDER", idNext);
                } else {
                    document.querySelector("#next_search_link").style.display = "none";
                }
            }
            return true;
        };

        prevNode.querySelector("a").onclick = async function(e) {
            if (document.querySelector("#prev_search_link").getAttribute("href") != "#") {
                return true;
            }
            e.preventDefault();
            await fetcherFunc();
            if (document.ids[0] != undefined) {
                window.location.href = document.querySelector("#prev_search_link").href;
            }
            return false;
        };
        nextNode.querySelector("a").onclick = async function(e) {
            if (document.querySelector("#next_search_link").getAttribute("href") != "#") {
                return true;
            }
            e.preventDefault();
            await fetcherFunc();
            if (document.ids[1] != undefined) {
                window.location.href = document.querySelector("#next_search_link").href;
            }
            return false;
        };

        if (hasPrevNext()) {
            fetcherFunc();
        }

        container.prepend(prevNode);
        container.append(nextNode);
        

        

        


    })()
</script>
						<script type="text/javascript">
				document.showNotesCaptcha = true;
                document.noteCaptcha = true;
</script>

<div id="note-container">
     
</div>
<script type="text/javascript">
    image = {'domain':'https://wimg.rule34.xxx/', 'width':1550, 'height':1094,'dir':7617, 'img':'c6468106d221b45d006ddc759185f08d.png', 'base_dir':'images', 'sample_dir':'samples', 'sample_width':'850', 'sample_height':'600'};	
</script>

            <img alt="3girls asahina_aoi big_breasts breasts busty danganronpa danganronpa_3 dark-skinned_female dark_skin female female_only hourglass_figure huge_breasts hypnosis kirigiri_kyouko large_breasts light-skinned_female light_skin long_hair mind_control multiple_females multiple_girls naked nipples nude pale-skinned_female pale_skin ponytail pussy shinzu031 voluptuous voluptuous_female yukizome_chisa" 
            src="https://wimg.rule34.xxx//samples/7617/sample_c6468106d221b45d006ddc759185f08d.jpg?8690920"
            id="image" 
            onclick="Note.toggle();" 
            width="850"
            height="600" 
        />
        <div style="margin-bottom: 1em;">
        <p id="note-count"></p>
    </div>
    
    <script type="text/javascript">
        

        Note.post_id = 8690920;
                Note.updateNoteCount();
        Note.show();
    </script>
						
						<span data-nosnippet>
												</span> 

						<h4 class="image-sublinks">
	<a href="#" onclick="Javascript:toggleEditForm(); return false;">Edit</a> 
					 | Create an account to comment	
			</h4>
									
					</div>

					<div data-nosnippet class="postViewSidebarRight verticalFlexWithMargins">
						<ins class="eas6a97888e38" data-zoneid="5232458"></ins> 
    						<script src="//cdn.tsyndicate.com/sdk/v1/ms.js"
 data-ts-spot="HQFN0yMawr8AmTRubAPgm96XJEnRYDbv"
 data-ts-template-id="11"
 async defer></script>
    						 
<ins class="eas6a97888e38" data-zoneid="4463770"></ins> 
    					</div>
				</div>

			</div>



			<div id="edit-form">
	<form method="post" action="/public/edit_post.php" id="edit_form" name="edit_form" style="display:none">
		<table>
			<tr><td>

				Rating:<br />

				
												<input type="radio" name="rating" value="e" id="rating_e" checked />
							<label for="rating_e">Explicit</label>
												<input type="radio" name="rating" value="q" id="rating_q"  />
							<label for="rating_q">Questionable</label>
								</td></tr>
			<tr><td>
					Title<br />
					<input type="text" name="title" id="title" value="" />
			</td></tr>
			<tr><td>
					Parent<br />
					<input type="text" name="parent" value="5099299" />
			</td></tr>
			<tr><td>
				Source<br />
				<input type="text" name="source" size="40" id="source" value="https://hypnohub.net/index.php?page=post&amp;s=view&amp;id=104048" />
			</td></tr>
			<tr><td>
				Tags<br />
				<textarea cols="100" id="tags" name="tags" rows="8" tabindex="10">3girls asahina_aoi big_breasts breasts busty danganronpa danganronpa_3 dark-skinned_female dark_skin female female_only hourglass_figure huge_breasts hypnosis kirigiri_kyouko large_breasts light-skinned_female light_skin long_hair mind_control multiple_females multiple_girls naked nipples nude pale-skinned_female pale_skin ponytail pussy shinzu031 voluptuous voluptuous_female yukizome_chisa</textarea>
			</td></tr>
			<tr><td>
				My Tags<br />
				<div id="my-tags">
				<a href="index.php?page=account&s=options">Edit</a>
				</div>
			</td></tr>
			<tr><td>
				Recent Tags<br />
				multiple_females			</td></tr>
			<tr><td>
				<input type="hidden" name="id" value="8690920" />
			</td></tr>
			<tr><td>
				<input type="hidden" name="pconf" id="pconf" value="0"/>
			</td></tr>
			<tr><td>
				<input type="hidden" name="lupdated" id="lupdated" value="1711431954"/>
			</td></tr>
			<tr><td>
				<div class="cf-turnstile" data-sitekey="0x4AAAAAAAES4wLGEtgDhNX6"></div><input type="hidden" name="captchaKey" value="tst2" />			</td></tr>
			<tr><td>
				<input type="submit" name="submit" value="Save changes" />
			</td></tr>
		</table>
	</form>
</div>
<script type="text/javascript">
	document.querySelector('#pconf').value=1;	
</script>
<script type="text/javascript">
	var my_tags = Cookie.get("tags");
	var tags = document.querySelector('#tags').value.split(' ');
	var my_tags_length = my_tags.length;
	var temp_my_tags = Array();
	var g = 0;
	for(i in my_tags)
	{
		if(my_tags[i] != "" && my_tags[i] != " " && i <= my_tags_length)
		{
			temp_my_tags[g] = my_tags[i];				
			g++;
		}
	}
		my_tags = temp_my_tags;
	var links = '';
	j = 0;
	my_tags_length = my_tags.length;
	for(i in my_tags)
	{
		if(j < my_tags_length)
		{
			if(!tags.includes(my_tags[i]))
			{
				links = links+'<a href="index.php?page=post&amp;s=list&amp;tags='+my_tags[i]+'" id="t_'+my_tags[i]+'"' + "onclick=\"javascript:toggleTags('"+my_tags[i]+"','tags','t_"+my_tags[i]+"');" + 'return false;">'+my_tags[i]+'</a> ';
			}
			else
			{
				links = links+'<a href="index.php?page=post&amp;s=list&amp;tags='+my_tags[i]+'" id="t_'+my_tags[i]+'"' + "onclick=\"javascript:toggleTags('"+my_tags[i]+"','tags','t_"+my_tags[i]+"');" + 'return false;"><b>'+my_tags[i]+'</b></a> ';
			}
		}
		j++;
	}
	if(j > 0)
		$('my-tags').innerHTML=links;
	else
		$('my-tags').innerHTML='<a href="index.php?page=account&amp;s=options">Edit</a>';
</script>
<script>
function toggleEditForm() {
	var form = "edit_form";
	if ($(form).style.display=='none') {
		$(form).show().scrollTo(); 
		$('tags').focus();
		
      if (!("captchaIncluded" in document)) {
        document.captchaIncluded = true;
        var script = document.createElement("script");
        script.src = "https://challenges.cloudflare.com/turnstile/v0/api.js";
        document.head.appendChild(script); 
      }
    	} else {
		$(form).hide();
	}
}
</script>
			
			<div id="post-comments">
    <div id="comment-list">

        <script type="text/javascript">
            var posts = {}; posts[8690920] = {}; posts[8690920].comments = {}; posts[8690920].ignored = {}; var cthreshold = parseInt(Cookie.get('comment_threshold')) || -5;
        </script>

         
            3 comments 
            <a href="#" id="ci" onclick="showHideIgnored(8690920,'ci'); return false;"> (0 hidden)</a>
            <br /> <br/>
        
        
                    <div id="c15882158">
                <div class="col1">
                    <a href="index.php?page=account&amp;s=profile&amp;uname=jubadchi">jubadchi</a>
                    <span style="font-size: 11px; color: #8f8f8f;">
                        &gt;&gt; #15882158                    </span>
                    <br />
                    <b>
                        Posted on 2023-09-24 21:47:10 
                        Score: <a id="sc15882158">4</a> 
                            (vote <a href="#" onclick="Javascript:vote('8690920', '15882158', 'up'); return false;">Up</a>)
                            (                                <a id="rc15882158"></a>
                                <a href="#" id="rcl15882158" onclick="Javascript:cflag('15882158'); return false;">Report comment</a>
                            )
                        
                                            </b>
                </div>
                <div class="col2">
                                            My three favorite girls from the DR Anime<br />                    
                                    </div>

                <script type="text/javascript">
                    posts[8690920].comments[15882158] = {'score':4, 'user':'jubadchi'}
                </script>
                                <hr class="light"/>
            </div>

            
                    <div id="c17059996">
                <div class="col1">
                    <a href="index.php?page=account&amp;s=profile&amp;uname=CatboyDomShu">CatboyDomShu</a>
                    <span style="font-size: 11px; color: #8f8f8f;">
                        &gt;&gt; #17059996                    </span>
                    <br />
                    <b>
                        Posted on 2023-12-11 16:45:49 
                        Score: <a id="sc17059996">2</a> 
                            (vote <a href="#" onclick="Javascript:vote('8690920', '17059996', 'up'); return false;">Up</a>)
                            (                                <a id="rc17059996"></a>
                                <a href="#" id="rcl17059996" onclick="Javascript:cflag('17059996'); return false;">Report comment</a>
                            )
                        
                                            </b>
                </div>
                <div class="col2">
                                            Why using a brainwashing video when just a quick selfie of my adorable cat face is enough Nyah~ just one look and womans brain ROT in love from how SUPERIORITY BY CUTE ALPHA I am~<br />                    
                                    </div>

                <script type="text/javascript">
                    posts[8690920].comments[17059996] = {'score':2, 'user':'catboydomshu'}
                </script>
                                <hr class="light"/>
            </div>

            
                    <div id="c17190532">
                <div class="col1">
                    <a href="index.php?page=account&amp;s=profile&amp;uname=Male_teacher">Male_teacher</a>
                    <span style="font-size: 11px; color: #8f8f8f;">
                        &gt;&gt; #17190532                    </span>
                    <br />
                    <b>
                        Posted on 2023-12-19 18:14:49 
                        Score: <a id="sc17190532">3</a> 
                            (vote <a href="#" onclick="Javascript:vote('8690920', '17190532', 'up'); return false;">Up</a>)
                            (                                <a id="rc17190532"></a>
                                <a href="#" id="rcl17190532" onclick="Javascript:cflag('17190532'); return false;">Report comment</a>
                            )
                        
                                            </b>
                </div>
                <div class="col2">
                                            I want to breed Aoi so badly. She has a perfect curvy, tanned, athletic body<br />                    
                                    </div>

                <script type="text/javascript">
                    posts[8690920].comments[17190532] = {'score':3, 'user':'male_teacher'}
                </script>
                                <hr class="light"/>
            </div>

            
        
    </div>

    <div id='paginator'> 
         <b>1</b> 
        <script type="text/javascript">
            filterComments(8690920, 3);
        </script>
    </div>
</div>			
			<div class="horizontalFlexWithMargins">
				<ins class="eas6a97888e38" data-zoneid="4975732"></ins> 
											</div>

			<div class="horizontalFlexWithMargins">
							</div>
			<br /><br />
		
		</div>
	</div>
</div>

    
<script>(AdProvider = window.AdProvider || []).push({"serve": {}});</script>
    

<!--  -->
<!--  -->

<div style="text-align: center; font-size: smaller;">
    <p>
        <a href="#" onclick="reset_cookie_consent()">Reset cookie / GDPR consent</a>
    </p>
</div>

<script>
    function reset_cookie_consent() {
        if (confirm("This will reset your cookie preferences and GDPR settings, continue?")) {
            Cookie.remove('gdpr'); Cookie.remove('gdpr-consent'); Cookie.remove('gdpr-disable-ga');
            document.location.reload();
        }
    }
</script>

<br />
<br />
<br />

<center style="font-size: x-small">
    </center>

<script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'9fb37566bcb21ce8',t:'MTc3ODY5NDEzNA=='};var a=document.createElement('script');a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body></html>